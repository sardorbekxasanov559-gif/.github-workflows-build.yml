# Media.uzai shahri — Android build starter

## Muhim
`index.html` hozircha namuna fayl. Uni o'zingiz yuborgan to'liq Media.uzai shahri HTML kodi bilan almashtiring.

## GitHub'ga yuklash
Ushbu ZIP'ni oching va ichidagi barcha fayl hamda `.github` papkasini repository'ning asosiy (root) qismiga yuklang. GitHub'da yashirin `.github` papkasi ham saqlanishi kerak.

## APK/AAB yig'ish
GitHub repository → Actions → Build Media Uzai Android → Run workflow.
Jarayon tugagach, Actions run sahifasining Artifacts qismidan `Media-Uzai-Android` faylini yuklab oling.

`app-debug.apk` — Android telefonda sinash uchun.
`app-debug.aab` — debug bundle; Google Play uchun release signing bilan alohida tayyorlash kerak.

Eslatma: bu loyiha internetdagi Three.js CDN manbasiga tayanadi, shu sababli o'yinning 3D qismi uchun internet kerak bo'ladi.
